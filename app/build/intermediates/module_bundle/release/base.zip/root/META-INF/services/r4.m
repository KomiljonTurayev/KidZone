q4.a
