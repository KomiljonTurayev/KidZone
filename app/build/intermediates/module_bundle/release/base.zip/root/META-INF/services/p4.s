q4.b
